package booksys.application.domain;

public class Waiting {
	private String name ;
	private String phoneNumber;
	
	public Waiting(String n, String pn) {
		name = n;
		phoneNumber = pn;
	}
	public String getName() {
		return name;
	}
	public String getPhoneNumber() {
	    return phoneNumber;
	}
}

