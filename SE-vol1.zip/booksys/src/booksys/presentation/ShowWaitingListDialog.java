package booksys.presentation;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import booksys.application.domain.Waiting;

public class ShowWaitingListDialog extends Dialog {
	protected TextArea name;
	protected TextArea phone ;
	protected TextArea num;
	protected Label waitingLabel;
	protected boolean confirmed;
	public static ArrayList<Waiting> waitingList = new ArrayList<>();
	int waitingNum = 1;
	
	ShowWaitingListDialog(Frame owner, String title)
	{
	    this(owner, title, null) ;
	}
	// This constructor initializes fields with data from an existing booking.
	// This is useful for completing Exercise 7.6.
	ShowWaitingListDialog(Frame owner, String title, Waiting wl){
		super(owner,title,true);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				confirmed = false ;
				ShowWaitingListDialog.this.hide() ;
			}
		});
		setLayout( new GridLayout(0, 1) ) ;
		
	    Button ok = new Button("Ok") ;
	    ok.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		confirmed = true;
	    		ShowWaitingListDialog.this.hide() ;
	    	}
	    }) ;
	    Button delete = new Button("DELETE ALL") ;
	    delete.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		confirmed = false;
	    		ShowWaitingListDialog.this.hide() ;
	    	}
	    }) ;
	    
	    Label warningLabel = new Label() ;
	    Label nameTag = new Label("����ȣ   �̸�        ��ȭ��ȣ") ;
	    add(delete) ;
	    add(warningLabel);
	    add(ok) ;
	    add(nameTag);
	    pack();
	}
	public void addWaitingList(Waiting waiting) {
		waitingList.add(waiting);
	}
	public void removeWaitingList() {
		waitingList.clear();
		waitingNum = 1;
	}
	public void makeWaitingList(Waiting waiting) {
			waitingLabel = new Label("    "
					+waitingNum +"           "
					+waiting.getName()+"    "
					+waiting.getPhoneNumber());
			
			add(waitingLabel);
			waitingNum++;
	}
	boolean isConfirmed(){
		return confirmed ;
	}
	
}
