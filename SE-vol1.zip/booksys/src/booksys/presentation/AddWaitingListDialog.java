package booksys.presentation;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import booksys.application.domain.Waiting;

public class AddWaitingListDialog extends Dialog {
	protected TextField name;
	protected TextField phone ;
	protected boolean   confirmed ;
	
	AddWaitingListDialog(Frame owner, String title)
	  {
	    this(owner, title, null) ;
	  }
	
	AddWaitingListDialog(Frame owner, String title, Waiting wl){
		super(owner,title,true);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				confirmed = false ;
				AddWaitingListDialog.this.hide() ;
			}
		});
		Label nameLabel = new Label("Name:", Label.RIGHT) ;
	    name = new TextField(10) ;
	    if (wl != null) {
	        name.setText(wl.getName()) ;
	    }
	    
	    Label phoneLabel = new Label("Phone no:", Label.RIGHT) ;
	    phone = new TextField(15) ;
	    if (wl != null) {
	        phone.setText(wl.getPhoneNumber()) ;
	        
	    }
	    
	    Button ok = new Button("Ok") ;
	    ok.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		confirmed = true;
	    		AddWaitingListDialog.this.hide() ;
	    	}
	    }) ;
	    
	    Button cancel = new Button("Cancel") ;
	    cancel.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		confirmed = false ;
	    		AddWaitingListDialog.this.hide() ;
	    	}	
		});
	    
	    setLayout( new GridLayout(0, 2) ) ;
	    
	    add(nameLabel) ;
	    add(name);
	   
	    add(phoneLabel) ;
	    add(phone);
	    
	    add(ok) ;
	    add(cancel) ;
	    
	    pack() ;
	}
	public String getName() {
		return name.getText();
	}
	public String getPhone() {
		return phone.getText();
	}
	
	boolean isConfirmed(){
		return confirmed ;
	}
}

